# Get WhatsApp Group Members

Chrome extension that lists the members (contacts) of a WhatApp group. Built with Blazor WebAssembly.
