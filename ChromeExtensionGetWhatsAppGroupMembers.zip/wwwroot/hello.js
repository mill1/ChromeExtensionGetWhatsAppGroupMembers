﻿function HelloWorld() {
    alert("Hello World!");
}